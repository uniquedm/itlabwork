<HTML>
<TITLE>X8 Chat</TITLE>
<?php
	$myfile = fopen("message.txt", "r") or die("Unable to open file!");
	echo fread($myfile,filesize("message.txt"));
	fclose($myfile);
?>
